import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import App from './App';
import UserInfo from './UserInfo';
import './index.css';
import EmployeeList from './EmployeeList';
import SurveyStores from './SurveyStores';
import Navbar from './Navbar';
import SurveyBranches from './SurveyBranches';


ReactDOM.createRoot(document.getElementById('root')).render(
  <Router>
     <Navbar />
    <Routes>
      <Route path="/" element={<App />} />
      <Route path="/userinfo" element={<UserInfo />} />
      <Route path="/employees" element={<EmployeeList />} />
      <Route path="/survey-stores" element={<SurveyStores />} />
      <Route path="/survey-branches" element={<SurveyBranches />} />
    </Routes>
  </Router>
);
